package entities

/*
  User Struct, Containing all the information gained by the token
*/
type User struct {
  Id string
  Name string
  Photo string
  Price float64
  Quantity int64
}
