package main

import (
    //MUST CHANGE THIS DIRECTORY WHEN TESTING
    "VMC-Testing/controllers/demo_controller"
  	"net/http"
    "os"
    "fmt"
  	"io/ioutil"

  	"golang.org/x/oauth2"
  	"golang.org/x/oauth2/google"
)

var (
	googleOauthConfig *oauth2.Config
	oauthStateString = "pseudo-random"
)
func init() {
	os.Setenv("CLIENT_ID", "644153343980-lkn78chclnlj0cgs60makd6ak0aa323f.apps.googleusercontent.com")
	os.Setenv("SECRET_KEY", "d9zd7zKdByOaXO2sJ7bJikla")
	googleOauthConfig = &oauth2.Config{
		RedirectURL:  "http://localhost:3000/callback",
		ClientID:     os.Getenv("CLIENT_ID"),
		ClientSecret: os.Getenv("SECRET_KEY"),
		Scopes:       []string{"https://www.googleapis.com/auth/userinfo.email"},
		Endpoint:     google.Endpoint,
	}
}

func main() {
  /*
  demo_controller.Index parse file would be replaced with the HTML/JS Code for Logging
  in
  */
  http.HandleFunc("/", demo_controller.Index)
  http.HandleFunc("/login", handleGoogleLogin)
  http.HandleFunc("/callback", handleGoogleCallback)
  http.HandleFunc("/Login", demo_controller.Login)
  http.ListenAndServe(":3000", nil)
}

func handleGoogleLogin(w http.ResponseWriter, r *http.Request) {
  //This calls the authentication function and redirects to the URL
	url := googleOauthConfig.AuthCodeURL(oauthStateString)
	http.Redirect(w, r, url, http.StatusTemporaryRedirect)
}

func handleGoogleCallback(w http.ResponseWriter, r *http.Request) {
  // Could get rid of this block and just re-direct.
	content, err := getUserInfo(r.FormValue("state"), r.FormValue("code"))
	if err != nil {
		fmt.Println(err.Error())
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
		return
	}
  fmt.Println(content)
	http.Redirect(w, r, "/Login", http.StatusTemporaryRedirect)
}

func getUserInfo(state string, code string) ([]byte, error) {
	if state != oauthStateString {
		return nil, fmt.Errorf("invalid oauth state")
	}

	token, err := googleOauthConfig.Exchange(oauth2.NoContext, code)
	if err != nil {
		return nil, fmt.Errorf("code exchange failed: %s", err.Error())
	}

	response, err := http.Get("https://www.googleapis.com/oauth2/v2/userinfo?access_token=" + token.AccessToken)
	if err != nil {
		return nil, fmt.Errorf("failed getting user info: %s", err.Error())
	}

	defer response.Body.Close()
	contents, err := ioutil.ReadAll(response.Body)
	if err != nil {
		return nil, fmt.Errorf("failed reading response body: %s", err.Error())
	}

	return contents, nil
}
