package main

import (
    "database/sql"
    "fmt"
    "encoding/json"
    "strings"
    "net/http"
    "io/ioutil"

    _"github.com/lib/pq"
)

const (
  host       = "localhost"
  port       = 5432
  user       = "postgres"
  password   = "pimSim"
  dbname     = "pimSim"
)

func main(){
  http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request ){
    http.ServeFile(w, r, r.URL.Path[1:])
  })
  http.HandleFunc("/print/", databasePrint )
  http.HandleFunc("/test/", test )
  http.ListenAndServe(":8080", nil)
}

func databasePrint( w http.ResponseWriter, r *http.Request ) {


  bytes, error := ioutil.ReadAll(r.Body)
  if error != nil {
    panic(error)
  }
  bodyString := string(bytes)
  fmt.Println(bodyString)


  psqlInfo := fmt.Sprintf("host=%s port=%d user=%s " + "password=%s dbname=%s sslmode=disable", host, port, user, password, dbname)

  db,err := sql.Open("postgres", psqlInfo)
  if err != nil {
    panic(err)
  }
  defer db.Close()

  err = db.Ping()
  if err != nil{
    panic(err)
  }

  sqlStatement := "SELECT percentagesID, percents FROM percentages WHERE percentagesID =$1;"

  var id int
  var percentages string

  row := db.QueryRow(sqlStatement, 1)

  switch err:= row.Scan(&id, &percentages ); err{
  case sql.ErrNoRows:
    fmt.Println("No rows were returned")
  case nil:
  default:
    panic(err)
  }

  percentages = strings.Replace(percentages, "{", "[", 1)
  percentages = strings.Replace(percentages, "}", "]", 1)

  var percentArray []int

  errConvert := json.Unmarshal( []byte(percentages), &percentArray )
  if errConvert != nil {
    panic(errConvert)
  }

  fmt.Println(percentArray)
  fmt.Fprintf(w, percentages , r.URL.Path[1:] )
}

func test(w http.ResponseWriter, r *http.Request ) {
  fmt.Fprintf(w, "Testing", r.URL.Path[1:] )
}
