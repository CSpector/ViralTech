package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"os"

	"golang.org/x/oauth2"
	"golang.org/x/oauth2/google"
)
//https://godoc.org/golang.org/x/oauth2/google
//https://www.googleapis.com/oauth2/v2/userinfo?access_token=
//https://www.googleapis.com/auth/userinfo.email
// /https://godoc.org/golang.org/x/oauth2/google#example-package--WebServer

// GoLang Web Server, Will need to repurpose for TGen North. (Google Sign-In / Database Entry)
//https://github.com/josephspurrier/gowebapp

// MVC Using GoLang, Step by Step
// https://www.calhoun.io/using-mvc-to-structure-go-web-applications/
var (
	googleOauthConfig *oauth2.Config
	oauthStateString = "pseudo-random"
)


// Initialize ClientID / Secret Key for our Authentication Server
func init() {
	os.Setenv("CLIENT_ID", "644153343980-lkn78chclnlj0cgs60makd6ak0aa323f.apps.googleusercontent.com")
	os.Setenv("SECRET_KEY", "d9zd7zKdByOaXO2sJ7bJikla")
	googleOauthConfig = &oauth2.Config{
		RedirectURL:  "http://localhost:3000/callback",
		ClientID:     os.Getenv("CLIENT_ID"),
		ClientSecret: os.Getenv("SECRET_KEY"),
		Scopes:       []string{"https://www.googleapis.com/auth/userinfo.email"},
		Endpoint:     google.Endpoint,
	}
}

// Serves on LocalHost:3000
func main() {
	http.HandleFunc("/", handleMain)
	http.HandleFunc("/login", handleGoogleLogin)
	http.HandleFunc("/callback", handleGoogleCallback)
	fmt.Println(http.ListenAndServe(":3000", nil))
}

//Initial Log-in Screen
func handleMain(w http.ResponseWriter, r *http.Request) {
	var htmlIndex = `<html>
<body>
	<a href="/login">Google Log In</a>
</body>
</html>`

	fmt.Fprintf(w, htmlIndex)
}

//See how much information we can grab using the token?
// Try out different Domains, regular gmail, IRIS?

func handleGoogleLogin(w http.ResponseWriter, r *http.Request) {
	url := googleOauthConfig.AuthCodeURL(oauthStateString)
	http.Redirect(w, r, url, http.StatusTemporaryRedirect)
}
/*
This Function handles the callback from the handleGoogleLogin function
This function CALLS - getUserInfo()
*/
func handleGoogleCallback(w http.ResponseWriter, r *http.Request) {
	content, err := getUserInfo(r.FormValue("state"), r.FormValue("code"))
	if err != nil {
		fmt.Println(err.Error())
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
		return
	}

	fmt.Fprintf(w, "Content: %s\n", content)
}


/*
This Function retrieves the Users Information:
Content: {
  "id": "103019260612862483798",
  "email": "cbs262@nau.edu",
  "verified_email": true,
  "picture": "https://lh3.googleusercontent.com/a-/AAuE7mC7u3PBT0svwnXXwpQEPtwPBihGDhrhSLWI4lS7hA",
  "hd": "nau.edu"
}
*/

func getUserInfo(state string, code string) ([]byte, error) {
	if state != oauthStateString {
		return nil, fmt.Errorf("invalid oauth state")
	}

	token, err := googleOauthConfig.Exchange(oauth2.NoContext, code)
	if err != nil {
		return nil, fmt.Errorf("code exchange failed: %s", err.Error())
	}

	response, err := http.Get("https://www.googleapis.com/oauth2/v2/userinfo?access_token=" + token.AccessToken)
	if err != nil {
		return nil, fmt.Errorf("failed getting user info: %s", err.Error())
	}

	defer response.Body.Close()
	contents, err := ioutil.ReadAll(response.Body)
	if err != nil {
		return nil, fmt.Errorf("failed reading response body: %s", err.Error())
	}

	return contents, nil
}
