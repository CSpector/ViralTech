package demo_controller

import (
  "net/http"
  "text/template"
  "fmt"
  "VMC/entities"
)

type Data struct {
  Age int
  Username string
  User entities.User
}

/*
  This function is called by the main.go function. It takes the index.html file,
  parses it, then exectutes if no erros were detected.

  TRY: Parse Google-Sign in HTML File Instead

  Notes: data needs information from token.
        ERROR: Might occur if called main.go is called outside "VMC"
*/
func Index(response http.ResponseWriter, request *http.Request) {
  tmplt, err := template.ParseFiles("VMC-Testing/views/demo_controller/index.html")
  if err != nil {
    fmt.Println(err) // Debug Output
    response.WriteHeader(http.StatusInternalServerError) // Proper HTTP response
    return
  }
  data := Data {
    Age: 20,
    Username: "Colton",
    User: entities.User{
      Id: "p01",
      Name: "TGen North",
      Photo: "VMC-Testing/static/images/tgen.PNG",
      Price: 5,
      Quantity: 8,
    },
  }
  tmplt.Execute(response, data)
}

func Login(response http.ResponseWriter, request *http.Request) {
  tmplt, err := template.ParseFiles("VMC-Testing/views/demo_controller/template.html")
  if err != nil {
    fmt.Println(err) // Debug Output
    response.WriteHeader(http.StatusInternalServerError) // Proper HTTP response
    return
  }
  data := Data {
    Age: 20,
    Username: "Colton",
    User: entities.User{
      Id: "p01",
      Name: "TGen North",
      Photo: "VMC-Testing/static/images/tgen.PNG",
      Price: 5,
      Quantity: 8,
    },
  }
  tmplt.Execute(response, data)
}
