package demo_controller

import (
  "net/http"
  "text/template"
  "fmt"
  "VMC/entities"
)

type Data struct {
  Age int
  Username string
  Product entities.Product
}

// Parse Google-Sign in
func Index(response http.ResponseWriter, request *http.Request) {
  tmplt, err := template.ParseFiles("VMC/views/demo_controller/index.html")
  if err != nil {
    fmt.Println(err) // Debug Output
    response.WriteHeader(http.StatusInternalServerError) // Proper HTTP response
    return
  }
  data := Data {
    Age: 20,
    Username: "Colton",
    Product: entities.Product{
      Id: "p01",
      Name: "TGen North",
      Photo: "VMC/static/images/tgen.PNG",
      Price: 5,
      Quantity: 8,
    },
  }
  tmplt.Execute(response, data)
}
