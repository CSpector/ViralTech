package main

import (
    "VMC/controllers/demo_controller"
  	"net/http"
)

func main() {
  http.HandleFunc("/", demo_controller.Index)
  http.HandleFunc("/demo/index", demo_controller.Index)
  http.ListenAndServe(":3000", nil)
}
