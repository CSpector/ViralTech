package entities

type Product struct {
  Id string
  Name string
  Photo string
  Price float64
  Quantity int64
}
