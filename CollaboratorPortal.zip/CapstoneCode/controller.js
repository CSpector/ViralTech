window.packages;
window.spreadsheet;
window.pacID;
window.token;

function initialize(callback){
  var params = getUrlVars();

  window.pacID = params["pacid"];
  window.token = params["id"];

  var param = {
    token : params["id"],
  };

  	$.ajax({
  		type: 'post',
  		url: '/initialize/',
  		dataType: 'json',
  		contentType: 'application/json',
  		data:JSON.stringify(param),

  		success: function(response){
            if( JSON.stringify(response) == "User not found")
            {
              alert( JSON.stringify(response) );
              return;
            }
              window.packages = response;

              callback();
  				}
  			});

}

function createButtons( divID, callback )
{
  var index;

  if( window.packages[0].packageID == undefined )
  {
    alert( "Something went wrong: Packages not initialized" );
    return;
  }

  for( index = 0; index < window.packages.length; index++ )
  {
    var img = document.createElement('img');
    var btn = document.createElement("input");
    btn.type = "button";
    btn.name = window.packages[index].packageID;
    btn.value = window.packages[index].packageDate;
    btn.id = window.packages[index].packageID;
    btn.style.backgroundColor = "#00868B";
    btn.style.color = "white";
    btn.style.width = "220px";
    btn.style.height = "45";
    btn.style.fontSize = "23px";
    btn.style.borderRadius = "20px";
    btn.style.hover = "blue";

    switch( window.packages[index].stepID )
    {
      case 1:
            img.src = '/tgen/images/metadata.png';
            img.title = "Filling out Metadata"
            break;
      case 2:
            img.src = '/tgen/images/shipped.png'
            img.title = "Shipped to TGen North"
            break;
      case 3:
            img.src = '/tgen/images/proc.png'
            img.title = "Received by TGen North, processing samples"
            break;
      case 4:
            img.src = '/tgen/images/234.png'
            img.title = "Results Ready!"
            break;
    }

    img.height = 40;
    img.width = 40;

    btn.setAttribute("onClick","navSummaryPage(" + window.packages[index].packageID + ");");

    document.getElementById(divID).appendChild(btn);
    document.getElementById(divID).appendChild(img);
    document.getElementById(divID).appendChild(document.createElement("br"));
    document.getElementById(divID).appendChild(document.createElement("br"));
  }
  callback();
}
function openMetadata( )
{
  var params = getUrlVars();
  var container = document.getElementById('table');
  var saveButton = document.getElementById('save');
  var submitButton = document.getElementById('submit');
  var title = document.getElementById('metadataTitle');

  var param = {
    token: params["id"],
    packageID : parseInt(params["pacid"])
  };

  $.ajax({
    type: 'post',
    url: '/generateSpreadsheet/',
    dataType: 'json',
    contentType: 'application/json',
    data:JSON.stringify(param),

    success: function(response){
      window.spreadsheet = new Handsontable(container, {
      data: response.metadata,
      startRows: 50,
      startCols: response.columnHeaders.length,
      width: '75%',
      height: 700,
      rowHeights: 23,
      rowHeaders: true,
      colHeaders: response.columnHeaders,
      columns: JSON.parse(response.spreadsheetConfig),
      licenseKey: 'non-commercial-and-evaluation'
      });

      for( index = 0; index < window.packages.length; index++ )
      {
        if( window.packages[index].packageID == window.pacID )
        {
          title.innerHTML = "Metadata for Package Created On " + window.packages[index].packageDate;
          return;
        }
      }
        }
      });
}
function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        vars[key] = value;
    });
    return vars;
}

function onSignIn(googleUser) {
  var id_token;
  // Useful data for client-side scripts:
  var profile = googleUser.getBasicProfile();
  googleUser.disconnect();
  // The ID token you need to pass to your backend:
  id_token = googleUser.getAuthResponse().id_token;
  console.log("ID Token: " + id_token);

  window.location.href = "tgen/index.html#?id=" + id_token;
}

function signOut() {
    var revokeAllScopes = function() {
      auth2.disconnect();
    }
    document.location.href = "/Sign_in.html";
}

function navCreatePackage() {
  window.location.href = "/tgen/CreatePackage.html#?id=" + window.token;
}

function navMetadata() {
  window.location.href = "/tgen/MetadataForm.html#?pacid=" + window.pacID + "&id=" + window.token;
}
function createNewPackage() {
  sampleNum = document.getElementById("samples").value;

  var param = {
    token: window.token,
    sampleNumber : parseInt(sampleNum),
  };

  $.ajax({
    type: 'post',
    url: '/newPackage/',
    dataType: 'json',
    contentType: 'application/json',
    data:JSON.stringify(param),

    success: function(response){

      window.location.href = "/tgen/SummaryPage.html#?pacid=" + response + "&id=" + window.token;

    }
  })

}
function loadSummaryPage( ){
  bar = document.getElementById("progress");
  title = document.getElementById("summaryTitle");

  for( index = 0; index < window.packages.length; index++ )
  {
    if( window.packages[index].packageID == window.pacID )
    {
      bar.value = window.packages[index].stepID;
      title.innerHTML = "Package Created On " + window.packages[index].packageDate;
      return;
    }
  }
}

function navSummaryPage( pacID ){
  window.location.href = "/tgen/SummaryPage.html#?pacid=" + pacID + "&id=" + window.token;
  if( window.location.href.includes("/tgen/SummaryPage.html") )
  {
    window.location.reload();
  }
}

function updatePackage(){
  var data = [];
  //alert(window.spreadsheet.getColHeader(0));
  for( rowIndex = 0; rowIndex < window.spreadsheet.countRows(); rowIndex++ )
     {
       data[rowIndex] = {};
       for( colIndex = 0; colIndex < window.spreadsheet.countCols(); colIndex++ )
          {
           header = window.spreadsheet.getColHeader( colIndex );
           if( window.spreadsheet.getDataAtCell(rowIndex,colIndex) != null )
           {
             data[rowIndex][header] = window.spreadsheet.getDataAtCell(rowIndex,colIndex).toString();
           }
          }
     }

     var param = {
       token: window.token,
       packageID : parseInt(window.pacID),
       spreadsheet: data
     };

     $.ajax({
       type: 'post',
       url: '/updatePackage/',
       dataType: 'json',
       contentType: 'application/json',
       data:JSON.stringify(param),

       success: function(response){
         alert(response);
       }
     })
}
function insertPackage(){
  var data = [];

  if( !confirm("Data cannot be edited after submission.\n Are you sure you want to submit?") )
  {
    return;
  }


  for( rowIndex = 0; rowIndex < window.spreadsheet.countRows(); rowIndex++ )
     {
       data[rowIndex] = {};
       for( colIndex = 0; colIndex < window.spreadsheet.countCols(); colIndex++ )
          {
           header = window.spreadsheet.getColHeader( colIndex );
           if( window.spreadsheet.getDataAtCell(rowIndex,colIndex) != null )
           {
             data[rowIndex][header] = window.spreadsheet.getDataAtCell(rowIndex,colIndex).toString();
           }
          }
     }

     var param = {
       token: window.token,
       packageID : parseInt(window.pacID),
       spreadsheet: data
     };

     $.ajax({
       type: 'post',
       url: '/insertPackage/',
       dataType: 'json',
       contentType: 'application/json',
       data:JSON.stringify(param),

       success: function(response){
         alert(response);
       }
     })
}

function addNewSample(){
  //window.spreadsheet.alter('insert_row', window.spreadsheet.countRows(), 1);
  var param = {
    token: window.token,
    packageID : parseInt(window.pacID)
  };

  $.ajax({
    type: 'post',
    url: '/newSample/',
    dataType: 'json',
    contentType: 'application/json',
    data:JSON.stringify(param),

    success: function(response){
      window.spreadsheet.getData().push(JSON.parse(response));

      window.spreadsheet.render();
    }
  })

}

function trackingNumber()
{
  var trackingNumber = prompt("Please Enter Your Tracking Number", "XXXX-XXXX-XXXX-XXXX");

  if( trackingNumber == null )
  {
    return;
  }

  var param = {
    token: window.token,
    packageID : parseInt(window.pacID),
    trackingNumber : trackingNumber
  };

  $.ajax({
    type: 'post',
    url: '/addTracking/',
    dataType: 'json',
    contentType: 'application/json',
    data:JSON.stringify(param),

    success: function(response){
      if( response == "Success" ) {
        alert("Thank You For Submitting Tracking Number: " + trackingNumber);
      } else {
        alert("Something went wrong");
      }

    }
  })

}
