-- Table: pims2."package"

-- DROP TABLE pims2."package";

CREATE TABLE pims2."package"
(
    package_id serial NOT NULL,
    package_create_date date,
    package_receive_date date,
    package_group_id integer,
    package_temp_metadata json,
    package_step_id integer,
    package_error_count integer,
    CONSTRAINT package_pkey PRIMARY KEY (package_id),
    CONSTRAINT package_package_group_id_fkey FOREIGN KEY (package_group_id)
        REFERENCES pims2.project_group (group_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE pims2."package"
    OWNER to capstone;

    -- Table: pims2.user_group_bridge

    -- DROP TABLE pims2.user_group_bridge;

    CREATE TABLE pims2.user_group_bridge
    (
        user_id integer NOT NULL,
        group_id integer NOT NULL,
        CONSTRAINT user_group_bridge_pkey PRIMARY KEY (user_id, group_id),
        CONSTRAINT user_group_bridge_group_id_fkey FOREIGN KEY (group_id)
            REFERENCES pims2.project_group (group_id) MATCH SIMPLE
            ON UPDATE NO ACTION
            ON DELETE NO ACTION,
        CONSTRAINT user_group_bridge_user_id_fkey FOREIGN KEY (user_id)
            REFERENCES pims2."user" (user_id) MATCH SIMPLE
            ON UPDATE NO ACTION
            ON DELETE NO ACTION
    )

    TABLESPACE pg_default;

    ALTER TABLE pims2.user_group_bridge
        OWNER to capstone;

INSERT INTO pims2."user"(
        	user_first_name, user_last_name, user_email )
        	VALUES ('Ron' , 'Swanson' , 'mrronswanson2020@gmail.com');

INSERT INTO pims2.user_group_bridge( user_id , group_id )
VALUES( 327 , 1 );
